#IMPORTING FILES
from settings import *

#IMPORTING LIBRARIES
from random import uniform

#IMPORTING CLASSES
from sprites import Sprite, MovingSprite, AnimatedSprite, MusicBoxRect, CutsceneTrigger, CollectableSprite, Boss, NextLevelRect
from player import Player
from camera import Camera
import cutscene_scripts
from cutscene_engine import CutsceneManager



#LEVEL CLASS
class Level:

    #LEVEL CLASS CONSTRUCTOR
    def __init__(s, game, tmx_maps, level_frames, player_frames, boss_frames, background_tracks, sound_effects, music_volumes):

        #PASSING IN THE GAME
        s.game = game

        #CAMERA GROUP
        s.all_sprites = Camera()

        #SPRITE GROUPS
        s.collision_sprites = pygame.sprite.Group()
        s.semi_collision_sprites = pygame.sprite.Group()
        s.damage_sprites = pygame.sprite.Group()
        s.music_box_sprites = pygame.sprite.Group()
        s.cutscene_sprites = pygame.sprite.Group()
        s.collectable_sprites = pygame.sprite.Group()
        s.enemy_sprites = pygame.sprite.Group()
        s.next_level_sprites = pygame.sprite.Group()

        #BACKGROUND MUSIC MENAGER
        s.background_tracs = background_tracks
        s.current_music_id = None
        s.switching_music = False
        s.music_volumes = music_volumes
        s.music_volume = 0.0
        s.sound_effects = sound_effects
        s.music_box_to_kill = None

        #BACKGROUND COLOUR MENAGER
        s.current_bg_colour = pygame.Color('#ADD8E6')
        s.target_bg_colour = s.current_bg_colour
        s.colour_transition_speed = 1

        #TRANSITION / TINT ATTRIBUTES
        s.tmx_maps = tmx_maps
        s.transition_target = s.tmx_maps[0]
        s.tint_surface = level_frames['tint_screen']
        s.tint_rect = s.tint_surface.get_frect(bottomleft = (0,0))
        s.tint_mode = 'untint'
        s.tint_speed = 1500

        #SETUP ATTRIBUTES
        s.level_frames = level_frames
        s.player_frames = player_frames
        s.boss_frames = boss_frames

        #INITIALIZING THE LEVEL
        s.setup(s.transition_target, level_frames, player_frames, boss_frames, sound_effects)

        #CAMERA TARGET
        s.camera_target = s.player
        s.cutscene_manager = CutsceneManager()
        
    #METHOD FOR SETTING MUSIC IN CUTSCENES
    def set_music(s, music_id):
        s.switching_music = True
        s.target_music = music_id
        s.fading_in = False

    #METHOD FOR HANDLING MUSIC
    def handle_music_boxes(s, player_rect):
        # Continue fading in music if already started
        if getattr(s, "fading_in", False) and s.target_music != 'none':
            if s.music_volume < s.target_volume:
                s.music_volume = min(s.target_volume, s.music_volume + 0.01)
                pygame.mixer.music.set_volume(s.music_volume)
            else:
                s.fading_in = False

        # Music box trigger check
        for box in s.music_box_sprites:
            if box.rect.colliderect(player_rect):
                s.switching_music = True
                s.target_music = box.music_id
                s.change_target_colour(box.colour)
                s.music_box_to_kill = box

        if s.switching_music:
            if s.music_volume > 0:
                s.music_volume = max(0, s.music_volume - 0.01)
                pygame.mixer.music.set_volume(s.music_volume)
            else:
                pygame.mixer.music.stop()

                if s.target_music != 'none':
                    track_path = s.background_tracs[s.target_music]
                    volume = s.music_volumes.get(s.target_music, 0.5)
                    pygame.mixer.music.load(track_path)
                    pygame.mixer.music.set_volume(0.0)
                    pygame.mixer.music.play(-1)

                    s.music_volume = 0.0
                    s.target_volume = volume
                    s.fading_in = True

                    if s.music_box_to_kill:
                        s.music_box_to_kill.kill()
                        s.music_box_to_kill = None
                else:
                    s.fading_in = False

                s.switching_music = False

    #METHOD FOR CHANGING THE TARGETED COLOUR
    def change_target_colour(s, hex_colour):
        s.target_bg_colour = pygame.Color(hex_colour)

    #METHOD FOR CHANGING BACKGROUND COLOUR
    def change_background_colour(s):
        for attr in ['r', 'g', 'b']:
            current = getattr(s.current_bg_colour, attr)
            target = getattr(s.target_bg_colour, attr)
            if current != target:
                step = s.colour_transition_speed
                if abs(current - target) < step:
                    setattr(s.current_bg_colour, attr, target)
                else:
                    direction = 1 if target > current else -1
                    setattr(s.current_bg_colour, attr, current + direction * step)

    #METHOD FOR MANAGING CUTSCENES
    def check_cutscene_triggers(s):
        for trigger in s.cutscene_sprites:
            if trigger.rect.colliderect(s.player.hitbox_rect):
                
                try:
                    cutscene_class = getattr(cutscene_scripts, trigger.name)
                    cutscene = cutscene_class(s)
                    cutscene.start()
                    trigger.kill()
                    break

                except AttributeError:
                    print(f"Cutscene class '{trigger.name}' not found.")

    #METHOD FOR CHECKING IF NEXT LEVEL
    def check_for_next_level(s):
        for sprite in s.next_level_sprites:
            if sprite.rect.colliderect(s.player.hitbox_rect):
                s.transition_target = s.tmx_maps[int(sprite.level_destination)]
                s.tint_mode = 'tint'

    #METHOD FOR DRAWING THE LEVEL
    def draw(s):

        #INTERPOLATING CURRENT COLOUR TOWARDS TARGET
        s.change_background_colour()

        #FILLING THE DISPLAY
        s.game.screen.fill(s.current_bg_colour)

        #DRAWING ALL SPRITES
        s.all_sprites.draw(s.game.screen, s.camera_target)

        #DRAWING THE TRANSITION TINT
        s.tint_screen(s.game.delta_time)
        
    #METHOD FOR RUNNING THE LEVEL
    def update(s, delta_time):
        
        #UPDATING ALL SPRITES
        for sprite in s.all_sprites:
            if sprite in s.collectable_sprites:
                sprite.update(delta_time, s.player)
            elif sprite in s.enemy_sprites:
                sprite.update(delta_time, s.player)
            else:
                sprite.update(delta_time)

        #UPDATING THE PLAYER MUSIC
        s.handle_music_boxes(s.player.hitbox_rect)

        #CHECHING FOR CUTSCENES
        s.check_cutscene_triggers()

        #CHECK FOR NEXT LEVEL
        s.check_for_next_level()

        if s.cutscene_manager.active:
            s.cutscene_manager.update(delta_time)

        if s.player.dead:
            s.tint_mode = 'tint'

    #SETTING UP THE LEVEL
    def setup(s, tmx_map, level_frames, player_frames, boss_frames, sound_effects):

        #CLEARING THE MAP - CLEARING ALL THE SPRITE GROUPS
        for group in (s.all_sprites, s.collision_sprites, s.semi_collision_sprites, s.damage_sprites, s.music_box_sprites, s.cutscene_sprites, s.collectable_sprites, s.enemy_sprites):
            group.empty()
        s.change_target_colour('#ADD8E6')
        s.current_bg_colour = pygame.Color('#ADD8E6')
        s.set_music('none')
        
        #SETTING UP THE LEVEL TILES
        for layer in ['main_terrain', 'background_terrain', 'foreground_terrain']:
            for x, y, surface in tmx_map.get_layer_by_name(layer).tiles():

                #SORTING THE LAYERS IN TO SPECIFIC GROUPS
                groups = [s.all_sprites]
                if layer == 'main_terrain' : groups.append(s.collision_sprites)

                #SETTING Z-INDEX FORM SETTINGS FOR FOREGROUND/BACKGROUND "3D" EFFECT
                match layer:
                    case 'background_terrain' : z = Z_LAYERS['background_terrain']
                    case 'foreground_terrain' : z = Z_LAYERS['foreground_terrain']
                    case _ : z = Z_LAYERS['main_terrain']

                Sprite((x * TILE_SIZE,y * TILE_SIZE), surface, groups, z)

        #SETTING UP THE LEVEL PLATFORMS
        for layer in ['platforms']:
            for x, y, surface in tmx_map.get_layer_by_name(layer).tiles():

                #SORTING THE LAYERS IN TO SPECIFIC GROUPS
                groups = [s.all_sprites, s.semi_collision_sprites]

                Sprite((x * TILE_SIZE,y * TILE_SIZE), surface, groups, Z_LAYERS['main_terrain'])

        #SETTING UP THE PALM PLATFORMS
        for object in tmx_map.get_layer_by_name('palm_platforms'):   
            #ANIMATION FRAMES
            frames = level_frames['palms'][object.name]

            #SETTING THE GROUPS
            groups = [s.all_sprites, s.semi_collision_sprites]

            #SETTING THE ANIMATION SPEED
            animation_speed = ANIMATION_SPEED + uniform(-1,1)

            #CREATING AN ANIMATIED SPRITE
            AnimatedSprite((object.x, object.y), frames, groups, Z_LAYERS['main_terrain'], animation_speed)

        #SETTING UP THE PLAYER
        for object in tmx_map.get_layer_by_name('player'):

            #SETTING UP THE PLAYER
            s.player = Player(
                level = s,
                pos = (object.x, object.y),
                groups = s.all_sprites,
                collision_sprites = s.collision_sprites,
                semi_collision_sprites = s.semi_collision_sprites,
                sound_effects = sound_effects,
                frames = player_frames,
                damage_sprites = s.damage_sprites,
                )
            

        #SETTING UP THE BACKGROUND DETAILS
        for object in tmx_map.get_layer_by_name('background_details'):

            Sprite((object.x, object.y), object.image, s.all_sprites, z = Z_LAYERS['background_details'])


        #SETTING UP THE ANIMATED BACKGROUND DETAILS
        for object in tmx_map.get_layer_by_name('animated_background_details'):

            #ANIMATION FRAMES
            if 'palm' in object.name:
                frames = level_frames['palms'][object.name]
            else:
                frames = level_frames[object.name]

            #SETTING THE GROUPS
            groups = [s.all_sprites]

            #SETTING THE ANIMATION SPEED
            if 'palm' in object.name:
                animation_speed = ANIMATION_SPEED + uniform(-1,1)
            elif 'chain' in object.name:
                animation_speed = uniform(1, 3)
            elif 'window' in object.name:
                animation_speed = uniform(3, 6)
            elif 'candle' in object.name:
                animation_speed = uniform(2, 8)
            else:
                animation_speed = ANIMATION_SPEED

            #CREATING AN ANIMATIED SPRITE
            AnimatedSprite((object.x, object.y), frames, groups, Z_LAYERS['background_details'], animation_speed)


        #SETTING UP THE ANIMATED PARTICLES
        for object in tmx_map.get_layer_by_name('animated_particles'):

            #ANIMATION FRAMES
            frames = level_frames[object.name]

            #SETTING THE GROUPS
            groups = [s.all_sprites]

            #SETTING THE ANIMATION SPEED
            if 'candle' in object.name:
                animation_speed = uniform(2, 6)
            else:
                animation_speed = ANIMATION_SPEED

            #CREATING AN ANIMATIED SPRITE
            AnimatedSprite((object.x-46, object.y-50), frames, groups, Z_LAYERS['foreground'], animation_speed)

        
        #SETTING UP THE LEVEL WATER
        if 'water' in [layer.name for layer in tmx_map.layers]:
            for object in tmx_map.get_layer_by_name('water'):
                # SETTING THE ROWS AND COLUMNS
                rows = int(object.height / TILE_SIZE)
                columns = int(object.width / TILE_SIZE)

                # ITERATING OVER THE WATER TILES
                for row in range(rows):
                    for column in range(columns):
                        x = object.x + column * TILE_SIZE
                        y = object.y + row * TILE_SIZE

                        if row == 0:
                            AnimatedSprite((x, y), level_frames['water_top'], s.all_sprites, Z_LAYERS['water'])
                        else:
                            Sprite((x, y), level_frames['water_body'], s.all_sprites, Z_LAYERS['water'])


        #SETTING UP THE COINS
        for object in tmx_map.get_layer_by_name('coins'):

            # ANIMATION FRAMES
            if object.name == 'gold':
                frames = level_frames['items']['gold']
                animation_speed = 10
            else:
                frames = level_frames['items']['silver']
                animation_speed = ANIMATION_SPEED

            # SETTING THE GROUPS
            groups = [s.all_sprites, s.collectable_sprites]

            # CREATE THE COLLECTABLE SPRITE
            CollectableSprite(pos = (object.x, object.y), frames = frames, groups = groups, collect_sound = sound_effects['coin'], z = Z_LAYERS['main_terrain'], animation_speed = animation_speed)


        #SETTING UP THE BACKGROUND DETAILS
        if 'foreground_details' in [layer.name for layer in tmx_map.layers]:
            for object in tmx_map.get_layer_by_name('foreground_details'):

                Sprite((object.x, object.y), object.image, s.all_sprites, z = Z_LAYERS['foreground'])

        
        #SETTING UP MOVING PLATFORMS
        for object in tmx_map.get_layer_by_name('moving_platforms'):

            #FRAMES OF ANIMATION
            frames = level_frames['helicopter']

            #SETTING THE GROUPS
            groups = (s.all_sprites, s.semi_collision_sprites)

            #CHECKING IF THE OBJECT IS VERTICAL OR HORIZONTAL
            if object.width > object.height: #HORIZONTAL
                move_direction = 'x'
                start_pos = (object.x, object.y + object.height / 2)
                end_pos = (object.x + object.width,object.y + object.height / 2)

            else: #VERTICAL
                move_direction = 'y'
                start_pos = (object.x + object.width / 2, object.y)
                end_pos = (object.x + object.width / 2,object.y + object.height)

            speed = object.properties['speed']

            #CREATING MOVABLE PLATOFRMS
            MovingSprite(frames, groups, start_pos, end_pos, move_direction, speed, object.properties['flip'])


        #SETTING UP MUSIC BOXES
        for object in tmx_map.get_layer_by_name('biome_rects'):

            MusicBoxRect((object.x, object.y), (object.width, object.height), object.properties['music'], s.music_box_sprites, object.properties['colour'])


        #SETTING UP CUTSCENE BOXES
        if 'cutscene_rects' in [layer.name for layer in tmx_map.layers]:
            for object in tmx_map.get_layer_by_name('cutscene_rects'):

                CutsceneTrigger((object.x, object.y), (object.width, object.height), object.name, s.cutscene_sprites)


        #SETTING UP BOSS
        if 'boss' in [layer.name for layer in tmx_map.layers]:
            for object in tmx_map.get_layer_by_name('boss'):

                s.boss = Boss((object.x, object.y), s, boss_frames, (s.all_sprites, s.enemy_sprites), (s.all_sprites, s.damage_sprites), sound_effects)

        #SETTING UP NEXT LEVEL COLLISION RECTS
        if 'next_level' in [layer.name for layer in tmx_map.layers]:
            for object in tmx_map.get_layer_by_name('next_level'):

                NextLevelRect((object.x, object.y), (object.width, object.height), s.next_level_sprites, object.name)


    #METHOD FOR TINTING THE SCREEN
    def tint_screen(s, delta_time):
        if s.tint_mode == 'untint':

            if s.tint_rect.bottom > 0:
                s.tint_rect.bottom -= s.tint_speed * delta_time

            if s.tint_rect.bottom <= 0:
                s.tint_rect.bottom = 0

        else:

            if s.tint_rect.bottom < WINDOW_HEIGHT:
                s.tint_rect.bottom += s.tint_speed * delta_time

            if s.tint_rect.bottom >= WINDOW_HEIGHT:
                s.tint_rect.bottom = WINDOW_HEIGHT
                s.setup(s.transition_target, s.level_frames, s.player_frames, s.boss_frames, s.sound_effects)
                s.camera_target = s.player
                s.tint_mode = 'untint'

        # Draw the tint surface over everything on the screen
        s.game.screen.blit(s.tint_surface, s.tint_rect)