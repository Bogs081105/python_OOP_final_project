#IMPROTING LIBRARIES
import json
from os import makedirs
from os.path import exists, dirname

#IMPROTING FILES
from settings import *


#FUNCTION FRO LOADING THE GAME DATA
def load_data(data_path, default_data):

    #CHECKING IF THE FILE EXISTS
    if exists(data_path):
        with open(data_path, 'r') as save_file:
            try:

                #TRYING TO LOAD THE SAVE FILE
                return json.load(save_file)
            
            #IF THE SAVE FILE DOES NOT LAOD
            except json.JSONDecodeError:
                print('Save file is corrupted.\nCreating a new one with default data!')

    
    #IF THE SAVE FILES DOES NOT EXIST OR IS CURRUPTED, CEATING IT WITH DEFAULT DATA FROM SETTINGS
    save_data(default_data, data_path)



#FUNCTION FOR SAVING DATA FILES
def save_data(data, save_path):

    #ENSURING THE DIRECTIORY EXISTS BEFORE WRITTING
    makedirs(dirname(save_path), exist_ok = True)

    #CREATING THE SAVE FILE
    with open(save_path, 'w') as save_file:
        json.dump(data, save_file, indent = 4)