#IMPORTING LIBRARIES
import pygame

#IMPORTING FILES
from settings import *
from support import import_image

#TIMER CLASS
class Timer:
    
    #TIMER CLASS CONSTRUCTOR
    def __init__(s, duration, function = None, repeat = False):
        s.duration = duration
        s.function = function
        s.start_time = 0
        s.active = False
        s.repeat = repeat

    #METHOD FOR ACTIVATING THE TIMER
    def activate(s):
        s.active = True
        s.start_time = pygame.time.get_ticks()

    #METHOD FOR DEACTIVATING THE TIMER
    def deactivate(s):
        s.active = False
        s.start_time = 0
        
        if s.repeat:
            s.activate()

    #METHOD FOR UPDATING THE TIMER
    def update(s):
        current_time = pygame.time.get_ticks()

        if current_time - s.start_time >= s.duration:
            if s.function and s.start_time != 0:
                s.function()
            s.deactivate()

#BALL CLASS
class Ball(pygame.sprite.Sprite):

    #BALL CLASS CONSTRUCTOR
    def __init__(s, game, x, y):

        #INITIALIZING INHERITANCE
        super().__init__()

        s.game = game
        s.image = import_image('..', 'graphics', 'player', 'jump', '5')
        s.image = pygame.transform.scale_by(s.image, 7)
        s.image = pygame.transform.flip(s.image, True, False)
        s.rect = s.image.get_frect(center = (x, y))
        s.velocity = 350

    #METHOD FOR UPDATING THE BALL
    def update(s, delta_time):

        s.rect.y += s.velocity * delta_time

        #RESSETING BALL TO TOP OF THE DISPLAY
        if s.rect.top > s.game.screen.get_height():
            s.rect.bottom = -60

    #METHOD FOR DRAWING THE BALL
    def draw(s):
        s.game.screen.blit(s.image, s.rect)

# BUTTON CLASS
class Button(pygame.sprite.Sprite):

    # BUTTON CLASS CONSTRUCTOR
    def __init__(s, game,
                text,
                pos,
                group = None,
                size = (200, 100),
                image_path = join('..', 'graphics', 'utils', 'button.png'),
                font_path = join('..', 'graphics', 'fonts', 'Pixelated.ttf'),
                text_size = 20,
                action = None):

        # INITIALIZING INHERITANCE
        super().__init__(group)

        # PASSING IN THE GAME AS AN ATTRIBUTE
        s.game = game

        #BUTTON ATTRIBUTES
        s.image = pygame.image.load(image_path).convert()
        s.image = pygame.transform.scale(s.image, size)
        s.rect = s.image.get_rect(topleft = pos)
        s.font = pygame.font.Font(font_path, text_size)
        s.text = s.font.render(text, False, (0,0,0))
        s.text_rect = s.text.get_rect(center= (s.rect.centerx, s.rect.centery + 5))
        s.action = action


    # METHOD FOR UPDATING THE BUTTON
    def update(s):

        # GETTING USER INPUT
        s.input()


    # METHOD FOR DRAWING THE BUTTON
    def draw(s):

        s.game.screen.blit(s.image, s.rect)
        s.game.screen.blit(s.text, s.text_rect)


    # METHOD FOR INPUT
    def input(s):

        # GETTING MOUSE POSITION AND INPUT
        mouse_pos = s.game.get_scaled_mouse_pos()
        mouse_press = pygame.mouse.get_just_pressed()[0]

        # CHECKING IF THE MOUSE IS OVER THE BUTTON
        if s.rect.collidepoint(mouse_pos):
            s.image.set_alpha(100)
        else:
            s.image.set_alpha(255)

        # ACTION WHEN PRESSING THE BUTTON
        if s.rect.collidepoint(mouse_pos) and mouse_press:
            if s.action:
                s.action()