#IMPORTING FILES
from settings import *

#IMPORTING LIBRARIES
from math import sin, cos, radians


#SPRITE CLASS
class Sprite(pygame.sprite.Sprite):

    #SPRITE CLASS CONSTRUCTOR
    def __init__(s, pos, surface = pygame.Surface((TILE_SIZE, TILE_SIZE)), groups = None, z = Z_LAYERS['main_terrain']):

        #INITIALIZING INHERITANCE
        super().__init__(groups)

        #SPRITE CLASS ATTRIBUTES
        s.image = surface

        #RECTANGLES
        s.rect = s.image.get_frect(topleft = pos)
        s.old_rect = s.rect.copy()

        #FOREGROUND/BACKGROUND "3D" EFFECT
        s.z = z

#ANIMATED SPRITE CLASS
class AnimatedSprite(Sprite):

    #ANIMATED SPRITE CONCSTUCTOR
    def __init__(s, pos, frames, groups, z = Z_LAYERS['main_terrain'], animation_speed = ANIMATION_SPEED):

        #ANIMATIED SPRITE ATTRIBUTES
        s.frames = frames
        s.frames_index = 0
        s.animation_speed = animation_speed

        #INITIALIZING INHERITANCE
        super().__init__(pos, s.frames[s.frames_index], groups, z)

    #ANIMATION METHOD
    def animate(s, delta_time):
        s.frames_index += s.animation_speed * delta_time
        s.image = s.frames[int(s.frames_index % len(s.frames))]

    #METHOD FOR UPDATING
    def update(s, delta_time):

        #ANIMATING THE SPRITE
        s.animate(delta_time)

#MOVING SPRITE
class MovingSprite(AnimatedSprite):
	
    #MOVING SPRITE CONSTRUCTOR
	def __init__(self, frames, groups, start_pos, end_pos, move_direction, speed, flip = False):
		
        #INITIALIZING INHERITANCE
		super().__init__(start_pos, frames, groups)
		
        #SETTING VERTICAL OR HORIZONTAL
		if move_direction == 'x':
			self.rect.midleft = start_pos
		else:
			self.rect.midtop = start_pos

        #START AND END POS ATTRIBUTES
		self.start_pos = start_pos
		self.end_pos = end_pos

		#MOVEMENT ATTRIBUTES
		self.moving = True
		self.speed = speed
		self.direction = vector(1,0) if move_direction == 'x' else vector(0,1)
		self.move_direction = move_direction

        #POSITIONING ATTRIBUTES
		self.flip = flip
		self.reverse = {'x': False, 'y': False}

    #METHOD FOR CHECKING MOVEMENT BORDERS
	def check_border(s):
		
        #HORIZONTAL
		if s.move_direction == 'x':
			if s.rect.right >= s.end_pos[0] and s.direction.x == 1:
				s.direction.x = -1
				s.rect.right = s.end_pos[0]
			if s.rect.left <= s.start_pos[0] and s.direction.x == -1:
				s.direction.x = 1
				s.rect.left = s.start_pos[0]
			s.reverse['x'] = True if s.direction.x < 0 else False
			
        #VERTICAL
		else:
			if s.rect.bottom >= s.end_pos[1] and s.direction.y == 1:
				s.direction.y = -1
				s.rect.bottom = s.end_pos[1]
			if s.rect.top <= s.start_pos[1] and s.direction.y == -1:
				s.direction.y = 1
				s.rect.top = s.start_pos[1]
			s.reverse['y'] = True if s.direction.y > 0 else False

    #METHOD FOR UPDATING MOVEING SPRITE
	def update(s, delta_time):
		
        #COPYING AND SETTING RECTANGLE
		s.old_rect = s.rect.copy()
		s.rect.topleft += s.direction * s.speed * delta_time
		
        #CHECKING IT'S BORDERS
		s.check_border()

        #ANIMATING THE SPRITE
		s.animate(delta_time)
		if s.flip:
			s.image = pygame.transform.flip(s.image, s.reverse['x'], s.reverse['y'])

#SPRITE FOR GOING TO THE NEXT LEVEL
class NextLevelRect(pygame.sprite.Sprite):
     
    def __init__(s, pos, size, groups, level_destination):
        super().__init__(groups)

        s.image = pygame.Surface(size)
        s.rect = s.image.get_frect(topleft=pos)

        s.level_destination = level_destination

    
#COLLECTABLE SPRITE CLASS
class CollectableSprite(AnimatedSprite):

    #COLLECTABLE SPRITE CONSTRUCTOR
    def __init__(s, pos, frames, groups, collect_sound, z=Z_LAYERS['main_terrain'], animation_speed=ANIMATION_SPEED):
        
        #INITALIZING INHERITANCE
        super().__init__(pos, frames, groups, z, animation_speed)

        #CLASS ATTRIBUTES
        s.collect_sound = collect_sound
        s.collected = False

    #METHOD FOR CHECKING COLLISION
    def check_collision_with_player(s, player):
        if not s.collected and player.hitbox_rect.colliderect(s.rect):
            s.collect()

    #METHOD FOR COLLECTING
    def collect(s):

        s.collect_sound.play()
        s.collected = True
        s.kill()

    #METHOD FOR UPDATING
    def update(s, delta_time, player):
        
        #ANIMATION THE COLLECTABLE
        s.animate(delta_time)

        #CHECKING COLLISIONS
        s.check_collision_with_player(player)


#MUSIC SPRITE
class MusicBoxRect(pygame.sprite.Sprite):

	#MUSIC BOX CONSTRUCTOR
    def __init__(s, pos, size, music_id, groups, colour = '#ADD8E6'):

		#INITIALIZNG INHERITANCE
        super().__init__(groups)

		#MUSIC BOX ATTRIBUTES
        s.image = pygame.Surface(size)
        s.rect = s.image.get_rect(topleft=pos)
		
        s.music_id = music_id
        s.colour = colour
		

#CLASS FOR CUTSCENE BOX
class CutsceneTrigger(pygame.sprite.Sprite):
	
    #CUTSCENE BOX CONSTRUCTOR
    def __init__(self, pos, size, name, groups):
		
        #INITIALIZNG INHERITANCE
        super().__init__(groups)
		
        #ATTRIBUTES
        self.image = pygame.Surface(size)
        self.rect = self.image.get_rect(topleft=pos)
        self.name = name

#CLASS FOR DAMAGE SPRITES
class DamageRect(pygame.sprite.Sprite):
    def __init__(s, pos, size, groups, sound, z = Z_LAYERS['path']):
        super().__init__(groups)
        s.z = z
        s.image = pygame.Surface(size)
        s.image.fill((255, 0, 0))  # Red rectangle
        s.image.set_alpha(0)  # Start invisible
        s.rect = s.image.get_rect(topleft=pos)

        # Duration and warning time
        s.creation_time = pygame.time.get_ticks()
        s.warning_duration = 800  # 1 second warning
        s.active_duration = 500    # After warning, damage lasts 0.5 sec

        # Damage flag
        s.is_damaging = False
        s.sound = sound

    def update(s, _):
        current_time = pygame.time.get_ticks()
        elapsed = current_time - s.creation_time

        # Fade in or blink as warning
        if elapsed < s.warning_duration:
            # Blink effect
            blink_interval = 20  # ms
            visible = (elapsed // blink_interval) % 4 == 0
            s.image.set_alpha(150 if visible else 0)

        elif not s.is_damaging:
            # Activate damage state
            s.is_damaging = True
            s.sound.play()
            s.image.set_alpha(255)  # Fully visible now

            # TODO: Trigger damage here (e.g., call player.damage())

        elif elapsed > s.warning_duration + s.active_duration:
            s.kill()

#BOSS CLASS
class Boss(pygame.sprite.Sprite):
    
    #BOSS CLASS CONSTRUCTOR
    def __init__(s, pos, level, frames, groups, damage_rects, sound_effects, z = Z_LAYERS['foreground'], animation_speed = ANIMATION_SPEED):
          
        #INITIALIZING INHERITANCE
        super().__init__(groups)
        s.z = z
        s.damage_rects = damage_rects
        s.level = level

        #BOSS ATTRIBUTES
        s.frames = frames
        s.sound_effects = sound_effects
        
        #ANIMATION SETUP
        s.state = 'idle'
        s.previous_state = s.state
        s.frame_index = 0
        s.image = s.frames[s.state][s.frame_index]
        s.animation_speed = animation_speed
        s.rect = s.image.get_frect(bottomright = pos)
        s.hitbox_rect = s.rect.inflate(-20, 0)

        #MOVEMENT AND COMBAT    
        s.health = 5
        s.speed = 20
        s.direction = vector(0, 0)

        #TIMERS AND FLAGS
        s.dead = False
        s.death_world = False
        s.after_cutscene = False
        s.facing_right = True

        #ATTACKING ATTRIBUTES
        s.attacking = False
        s.after_attack = False
        s.recently_hit = False
      

    #METHOD FOR MANAGING BOSS STATES
    def manage_state(s):
        if s.dead:
            s.animation_speed = 3
            s.state = 'death'
            if s.death_world:
                s.level.change_target_colour('#ADD8E6')
                s.level.set_music('none')
                s.sound_effects['boss_death'].play()
                s.death_world = False
        elif s.recently_hit:
             s.state = 'hit'
        elif s.attacking:
             s.state = 'attack'
        elif s.direction.magnitude() != 0:
            s.state = 'walk'
        else:
            s.state = 'idle'

        if s.previous_state != s.state:
            s.frame_index = 0

    #METHOD FOR UPDATING THE BOSS
    def update(s, delta_time, player):
        s.facing_right = player.hitbox_rect.center[0] > s.rect.centerx  # More accurate than comparing to rect.x

        s.manage_state()
        s.animate(delta_time)

        if s.after_cutscene and not s.dead:
            s.move_towards_player(player.hitbox_rect.center, delta_time)

        if player.player_attack_rect and not s.recently_hit:
            if player.player_attack_rect.colliderect(s.hitbox_rect) and s.state != 'attack':
                s.health -= 1
                s.recently_hit = True
                s.sound_effects['boss_hit'].play()
                s.hit_timer = pygame.time.get_ticks()
                print("Boss hit! Health:", s.health)

                if s.health <= 0:
                    s.death_world = True

        s.hitbox_rect.center = s.rect.center
        s.previous_state = s.state


    #METHOD FOR ANIMATING THE BOSS 
    def animate(s, delta_time):

        s.frame_index += s.animation_speed * delta_time
        frame_list = s.frames[s.state]
        frame_count = len(frame_list)


        if s.state == 'attack' and s.frame_index >= frame_count:
            s.state = 'idle'
            s.attacking = False
            s.after_attack = False
        elif s.state == 'attack' and int(s.frame_index) == 4 and not s.after_attack:
            s.attack()
            s.after_attack = True
        elif s.state == 'death' and s.frame_index >= frame_count:
            s.image = s.frames['death'][-1]
        elif s.state == 'hit' and s.frame_index >= frame_count:
            s.recently_hit = False
            if s.health <= 0:
                s.dead = True
        else:
            frame = frame_list[int(s.frame_index % frame_count)]
            s.image = pygame.transform.flip(frame, True, False) if s.facing_right else frame


    #METHOD FOR MOVING TOWARDS PLAYER
    def move_towards_player(s, player_pos, delta_time):
        player_distance = player_pos[0] - s.rect.x

        if player_distance > 300 and s.attacking == False:
            s.rect.x += s.speed * delta_time
            s.direction.x = 1
        else:
            s.direction.x = 0
            if s.state != 'hit':
                s.attacking = True


    #METHOD FOR ATTACKING PLAYER
    def attack(s):
        
        width, height = 250, s.rect.height * 0.4
        if s.facing_right:
            x = s.rect.right - 30
            y = s.rect.top + s.rect.height * 0.6
        else:
            x = s.rect.left - 220
            y = s.rect.top + s.rect.height * 0.6

        DamageRect((x, y), (width, height), s.damage_rects, s.sound_effects['boss_attack'], Z_LAYERS['path'])

