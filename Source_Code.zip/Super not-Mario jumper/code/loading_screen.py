#IMPORTING LIBRARIES
import pygame

#IMPORTING FILES
from settings import *


#LOADING SCREEN CLASS
class LoadingScreen:

    #LOADING SCREEN CLASS CONSTRUCTOR
    def __init__(s, game):

        #PASSING IN THE GAME AS AN ATTRIBUTE
        s.game = game

        #LOADING SCREEN ASSETS
        s.background = pygame.image.load(join('..', 'graphics', 'utils', 'loading_screen.png')).convert()


    #METHOD FOR UPDATING THE MENU
    def update(s, delta_time):
        pass

    #METHOD FOR DRAWING THE MENU
    def draw(s):
        s.game.screen.blit(s.background, (0,0))

