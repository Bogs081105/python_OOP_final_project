#IMPORTING LIBRARIES
import pygame
import threading
from sys import exit
from pytmx.util_pygame import load_pygame

#IMPORTING FILES
from settings import *
from support import *
from load_data import load_data, save_data

#IMPORTING CLASSES
from main_menu import MainMenu
from level import Level
from loading_screen import LoadingScreen


#GAME CLASS
class Game:

    #PERSONAL INFORAMTION ABOUT THE GAME
    def __str__(s):
        return '''
        Made by Dariusz J. Mirończuk
        '''
    
    #GAME CLASS CONSTRUCTOR
    def __init__(s):

        #INITIALIZING PYGAME
        pygame.init()

        #LOADING IN THE GAME DATA
        s.screen_data = load_data(SCREEN_DATA_PATH, DEFAULT_SCREEN_DATA)
        
        #DISPLAY SETUP
        s.display_setup()

        #INITIALIZING DISPLAY
        s.display = pygame.display.set_mode((s.screen_data['width'], s.screen_data['height']), s.flags)
        s.screen = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption('Super not-Mario jumper')

        #INITIALIZNG CLOCK
        s.clock = pygame.time.Clock()
        s.fps = s.screen_data['fps']

        #INITIALIZING GAME ELEMENTS
        s.main_menu = MainMenu(s)
        s.level = None
        s.overworld = None
        s.game_state = 'main_menu'   #ACTIVE GAME ELEMENT

        #ASSETS LOADING THREAD
        s.assets_loaded = False
        s.assets_thread = threading.Thread(target = s.import_assets, daemon = True)
        s.assets_thread.start()


    #METHOD FOR IMPORTING ALL ASSETS
    def import_assets(s):

        #LOADING IN THE MAPS
        s.tmx_maps = {0 : load_pygame(join('..', 'data', 'levels', 'level_0.tmx')),
                      1 : load_pygame(join('..', 'data', 'levels', 'level_1.tmx'))}

        #ALL LEVEL FRAMES
        s.level_frames = {
			'flag': import_folder('..', 'graphics', 'level', 'flag'),
			'saw': import_folder('..', 'graphics', 'enemies', 'saw', 'animation'),
			'floor_spike': import_folder('..', 'graphics','enemies', 'floor_spikes'),
			'palms': import_sub_folders('..', 'graphics', 'level', 'palms'),
			'candle': import_folder('..', 'graphics','level', 'candle'),
			'window': import_folder('..', 'graphics','level', 'window'),
			'big_chain': import_folder('..', 'graphics','level', 'big_chain'),
			'small_chain': import_folder('..', 'graphics','level', 'small_chain'),
			'candle_light': import_folder('..', 'graphics','level', 'candle_light'),
			'saw': import_folder('..', 'graphics', 'enemies', 'saw', 'animation'),
			'saw_chain': import_image('..',  'graphics', 'enemies', 'saw', 'saw_chain'),
			'helicopter': import_folder('..', 'graphics', 'level', 'helicopter'),
			'boat': import_folder('..',  'graphics', 'objects', 'boat'),
			'spike': import_image('..',  'graphics', 'enemies', 'spike_ball', 'Spiked Ball'),
			'spike_chain': import_image('..',  'graphics', 'enemies', 'spike_ball', 'spiked_chain'),
			'tooth': import_folder('..', 'graphics','enemies', 'tooth', 'run'),
			'shell': import_sub_folders('..', 'graphics','enemies', 'shell'),
			'pearl': import_image('..',  'graphics', 'enemies', 'bullets', 'pearl'),
			'items': import_sub_folders('..', 'graphics', 'items'),
			'particle': import_folder('..', 'graphics', 'effects', 'particle'),
			'water_top': import_folder('..', 'graphics', 'level', 'water', 'top'),
			'water_body': import_image('..', 'graphics', 'level', 'water', 'body'),
			'bg_tiles': import_folder_dictionary('..', 'graphics', 'level', 'bg', 'tiles'),
			'cloud_small': import_folder('..', 'graphics','level', 'clouds', 'small'),
			'cloud_large': import_image('..', 'graphics','level', 'clouds', 'large_cloud'),
            'tint_screen' : import_image('..', 'graphics', 'utils', 'tint_screen')
		}

        s.player_frames = {
            'idle' : import_folder('..', 'graphics', 'player', 'idle'),
            'jump' : import_folder('..', 'graphics', 'player', 'jump'),
            'run' : import_folder('..', 'graphics', 'player', 'run'),
            'wall_left' : import_folder('..', 'graphics', 'player', 'wall_left'),
            'wall_right' : import_folder('..', 'graphics', 'player', 'wall_right'),
            'katana_idle' : import_folder('..', 'graphics', 'player', 'katana_idle'),
            'katana_run' : import_folder('..', 'graphics', 'player', 'katana_run'),
            'attack' : import_folder('..', 'graphics', 'player', 'attack'),
            'special_attack' : import_folder('..', 'graphics', 'player', 'special_attack'),
            'hurt' : import_folder('..', 'graphics', 'player', 'hurt'),
            'death' : import_folder('..', 'graphics', 'player', 'death'),
        }

        for key, frame_list in s.player_frames.items():
            s.player_frames[key] = [pygame.transform.scale_by(frame, 2.5) for frame in frame_list]

        s.boss_frames = {
            'idle' : import_folder('..', 'graphics', 'enemies', 'level_1_boss', 'idle'),
            'walk' : import_folder('..', 'graphics', 'enemies', 'level_1_boss', 'walk'),
            'attack' : import_folder('..', 'graphics', 'enemies', 'level_1_boss', 'attack'),
            'hit' : import_folder('..', 'graphics', 'enemies', 'level_1_boss', 'hit'),
            'death' : import_folder('..', 'graphics', 'enemies', 'level_1_boss', 'death'),
        }

        for key, frame_list in s.boss_frames.items():
            s.boss_frames[key] = [pygame.transform.scale_by(frame, 2.5) for frame in frame_list]

        s.background_tracs = {
            'background_1.1' : join('..', 'audio', 'background_tracs', 'background_1.1.ogg'),
            'background_1.2' : join('..', 'audio', 'background_tracs', 'background_1.2.ogg'),
            'level_1_boss_fight' : join('..', 'audio', 'background_tracs', 'level_1_boss_fight.ogg'),
            'background_1.3' : join('..', 'audio', 'background_tracs', 'background_1.3.ogg'),
        }

        # SETTING DEFAULT MUSIC VOLUME
        s.music_volumes = {
            'background_1.1': 0.5,
            'background_1.2': 0.3,
            'level_1_boss_fight' : 0.9,
            'background_1.3': 0.5,
        }

        s.sound_effects = {
            'attack' : import_sound_effect('..', 'audio', 'attack', volume = 1.0),
            'jump' : import_sound_effect('..', 'audio', 'jump'),
            'coin' : import_sound_effect('..', 'audio', 'coin'),
            'boss_rawr' : import_sound_effect('..', 'audio', 'boss_rawr', volume = 1.0),
            'boss_death' : import_sound_effect('..', 'audio', 'boss_death', volume = 1.0),
            'boss_hit' : import_sound_effect('..', 'audio', 'boss_hit', volume = 1.0),
            'boss_attack' : import_sound_effect('..', 'audio', 'boss_attack', volume = 1.0),
        }

        # LOADING COMPLETE
        print('assets imported!')
        s.assets_loaded = True
    
    #METHOD FOR SCALING MOUSE POS
    def get_scaled_mouse_pos(s):
        mouse_x, mouse_y = pygame.mouse.get_pos()
        scaled_x = mouse_x * (s.screen.get_width() / s.display.get_width())
        scaled_y = mouse_y * (s.screen.get_height() / s.display.get_height())
        return int(scaled_x), int(scaled_y)

    #SETTING UP DISPLAY
    def display_setup(s):
        s.fullscreen = s.screen_data['fullscreen']
        s.last_window_size = (s.screen_data['width'], s.screen_data['height'])

        if s.fullscreen:
            s.flags = pygame.FULLSCREEN
        else:
            s.flags = pygame.RESIZABLE

    #SAVING THE GAME
    def save_game(s):

        #SAVING SCREEN DATA
        save_data(s.screen_data, SCREEN_DATA_PATH)

    #METHOD FOR CHANING ACTIVE GAME ELEMET
    def change_active_element(s, new_state):
        
        #IF THE STATE CHANGES TO A LEVEL
        if new_state == 'level':

            #CHECKING IF THE ASSETS LOADED IN
            if s.assets_loaded:
                s.level = Level(s, s.tmx_maps, s.level_frames, s.player_frames, s.boss_frames, s.background_tracs, s.sound_effects, s.music_volumes)   #DEFAULT TO LEVEL 1

            else:
                s.level = LoadingScreen(s)

        #CHANGING THE GAME STATE
        s.game_state = new_state

    #METHOD FOR HANDLING EVENTS
    def event_handler(s):
        for event in pygame.event.get():

            #CLOSING THE GAME IF EXIT ON THE WINDOW IS PRESSED
            if event.type == pygame.QUIT:
                s.save_game()
                pygame.quit()
                exit()

            #HANDLING VIDEO RESIZE
            if event.type == pygame.VIDEORESIZE and not s.fullscreen:

                #SAVING THE LAST NOT FULLSCREEND WINDOW SIZE
                s.screen_data['width'] = event.w
                s.screen_data['height'] = event.h

                #SETTING FULLSCREEN
                s.display = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)
                s.screen = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))

                #SAVING CHANGES
                save_data(s.screen_data, SCREEN_DATA_PATH)

            #GETTING USER BUTTON INPUT
            if event.type == pygame.KEYDOWN:

                #CLOSING GAME IF 'ESCAPE' BUTTON PRESSED
                if event.key == pygame.K_ESCAPE:
                    s.save_game()
                    pygame.quit()
                    exit()

                #TOGGLING FULLSCREEN MODE
                if event.key == pygame.K_9:
                    s.fullscreen = not s.fullscreen
                    s.screen_data['fullscreen'] = s.fullscreen

                    if s.fullscreen:
                        s.last_window_size = (s.display.get_width(), s.display.get_height())
                        s.flags = pygame.FULLSCREEN
                        s.display = pygame.display.set_mode((s.screen_data['width'], s.screen_data['height']), s.flags)
                    else:
                        s.flags = pygame.RESIZABLE
                        s.display = pygame.display.set_mode(s.last_window_size, s.flags)
                        s.screen_data['width'], s.screen_data['height'] = s.last_window_size

                    save_data(s.screen_data, SCREEN_DATA_PATH)

    #METHOD FOR UPDATING THE GAME
    def update(s):

        #SETTING THE FPS AND DELTA TIME
        s.delta_time = s.clock.tick(s.fps) / 1000

        #SWITCHING ACTIVE GAME PARTS
        if s.game_state == 'main_menu':
            s.main_menu.update(s.delta_time)

        elif s.game_state == 'overworld':
            pass

        elif s.game_state == 'level':
            s.level.update(s.delta_time)

    #METHOD FOR DRAWING THE GAME
    def draw(s):

        #FILLING THE IMAGE BLACK
        s.screen.fill((0,0,0))

        #DRAWING THE ACTIVE GAME ELEMENTS
        if s.game_state == 'main_menu':
            s.main_menu.draw()

        elif s.game_state == 'overworld':
            pass

        elif s.game_state == 'level':
            s.level.draw()


        #TRANSFORMING THE IMAGE TO PROPER DISPLAY | S.SCREEN ---> S.DISPLAY
        scaled_surface = pygame.transform.scale(s.screen, (s.display.get_width(), s.display.get_height()))

        #BLITTING THE SCALED IMAGE TO THE DISPLAY
        s.display.blit(scaled_surface, (0,0))

        #UPDATING THE DISPLAY
        pygame.display.update()

    #METHOD FOR RUNNING THE GAME
    def run(s):

        #MAIN GAME LOOP
        while True:

            #EVENT HANDLER
            s.event_handler()

            #UPDATING THE GAME
            s.update()

            #DRAWING THE GAME
            s.draw()


#RUNNING THE GAME ONLY FROM MAIN FILE
if __name__ == '__main__':
    game = Game()
    print(game)
    game.run()






