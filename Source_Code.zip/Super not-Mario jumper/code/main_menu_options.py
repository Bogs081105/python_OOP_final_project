#IMPORTING LIBRARIES
import pygame

#IMPORTING FILES
from settings import *
from support import import_image, import_folder
from utils import Button, Ball
from load_data import save_data


#OPTIONS CLASS
class MainMenuOptions:

    #LEVEL CLASS CONSTRUCTOR
    def __init__(s, game, sound_up, sound_down, sound_select):

        #PASSING IN THE GAME AS AN ATTRIBUTE
        s.game = game
        s.sound_up = sound_up
        s.sound_down = sound_down
        s.sound_select = sound_select

        #OPTIONS ASSETS
        s.background = import_image('..', 'graphics', 'utils', 'main_menu_options_background')
        s.buttons = pygame.sprite.Group()

        #BUTTONS FOR RESIZING DISPLAY
        s.fullscreen_button = Button(s.game, '1440', (100, 70), s.buttons, action = lambda: s.change_resolution(1920, 1080))
        s.one_zero_eight_zero_button = Button(s.game, '1080', (100, 180), s.buttons, action = lambda: s.change_resolution(1920, 1080))
        s.seven_two_zero_button = Button(s.game, '720', (100, 290), s.buttons, action = lambda: s.change_resolution(1280, 720))
        s.three_six_zero_button = Button(s.game, '360', (100, 400), s.buttons, action = lambda: s.change_resolution(640, 360))
        s.exit_button = Button(s.game, '<< Back', (20, 600), s.buttons, action = lambda: s.game.main_menu.change_active_mm_element('menu'))

        #BUTTON FOR CHANGING FPS
        s.one_two_zero_button = Button(s.game, '90 FPS', (400, 70), s.buttons, action=lambda: s.update_fps(90))
        s.nine_zero_button = Button(s.game, '60 FPS', (400, 180), s.buttons, action=lambda: s.update_fps(60))
        s.six_zero_button = Button(s.game, '30 FPS', (400, 290), s.buttons, action=lambda: s.update_fps(30))
        s.three_zero_button = Button(s.game, '15 FPS', (400, 400), s.buttons, action=lambda: s.update_fps(15))

        #FALLING BALL
        s.ball = Ball(s.game, 1000, 0)

        #COLUMNS
        s.columns = [
            [s.fullscreen_button, s.one_zero_eight_zero_button, s.seven_two_zero_button, s.three_six_zero_button],
            [s.one_two_zero_button, s.nine_zero_button, s.six_zero_button, s.three_zero_button],
            [s.exit_button]
        ]


        # INDICATOR SETUP FOR KEYBOARD/GAMEPAD CONTROL
        s.selected_button_index = 0
        s.selected_column_index = 0
        s.indicator_frames = import_folder('..', 'graphics', 'utils', 'indicator')

        #SCALING FRAMES
        s.indicator_frames = [pygame.transform.scale(frame, (240, 140)) for frame in s.indicator_frames]

        s.indicator_frame_index = 0
        s.indicator_frame_animation_speed = 2
        s.indicator_image = s.indicator_frames[0]
        s.indicator_rect = s.indicator_image.get_rect(center=s.columns[s.selected_column_index][s.selected_button_index].rect.center)


    #METHOD FOR UPDATING THE OPTIONS
    def update(s, delta_time):
        s.input()  # <--- This line is missing

        for button in s.buttons:
            button.update()

        s.ball.update(delta_time)
        s.animate(delta_time)

        # Move indicator to new selected button
        selected_button = s.columns[s.selected_column_index][s.selected_button_index]
        s.indicator_rect.center = selected_button.rect.center


    #METHOD FOR DRAWING THE OPTIONS
    def draw(s):
        s.game.screen.blit(s.background, (0,0))

        for button in s.buttons:
            button.draw()

        #DRAWING THE BALL
        s.ball.draw()

        s.game.screen.blit(s.indicator_image, s.indicator_rect)


    #METHOD FOR CHANGING THE RESOLUTION
    def change_resolution(s, width, height):
        s.game.screen_data['width'] = width
        s.game.screen_data['height'] = height
        s.game.display = pygame.display.set_mode((width, height), pygame.RESIZABLE)
        save_data(s.game.screen_data, SCREEN_DATA_PATH)  #SAVE RESOLUTION SETTINGS

    #METHOD FOR CHANGING FPS
    def update_fps(s, new_fps):
        s.game.fps = new_fps
        s.game.screen_data['fps'] = new_fps
        save_data(s.game.screen_data, SCREEN_DATA_PATH)

    #METHOD FOR ANIMATION
    def animate(s, delta_time):

        s.indicator_frame_index += s.indicator_frame_animation_speed * delta_time
        indicator_frame_count = len(s.indicator_frames)
        s.indicator_image = s.indicator_frames[int(s.indicator_frame_index % indicator_frame_count)]

    #METHOD FOR INPUT
    def input(s):
        keys = pygame.key.get_just_pressed()
        mouse = pygame.mouse.get_just_pressed()[0]

        col = s.columns[s.selected_column_index]
        
        # Vertical navigation
        if (keys[pygame.K_DOWN] or keys[pygame.K_s]) and s.selected_button_index < len(col) - 1:
            s.selected_button_index += 1
            s.sound_down.play()
        elif (keys[pygame.K_UP] or keys[pygame.K_w]) and s.selected_button_index > 0:
            s.selected_button_index -= 1
            s.sound_up.play()

        # Horizontal navigation
        if (keys[pygame.K_RIGHT] or keys[pygame.K_d]) and s.selected_column_index < len(s.columns) - 1:
            s.selected_column_index += 1
            s.selected_button_index = min(s.selected_button_index, len(s.columns[s.selected_column_index]) - 1)
        elif (keys[pygame.K_LEFT] or keys[pygame.K_a]) and s.selected_column_index > 0:
            s.selected_column_index -= 1
            s.selected_button_index = min(s.selected_button_index, len(s.columns[s.selected_column_index]) - 1)

        # Select button
        if keys[pygame.K_RETURN] or keys[pygame.K_KP_ENTER]:
            selected_button = s.columns[s.selected_column_index][s.selected_button_index]
            if hasattr(selected_button, 'action') and callable(selected_button.action):
                selected_button.action()
                s.sound_select.play()

        if mouse:
            s.sound_select.play()
