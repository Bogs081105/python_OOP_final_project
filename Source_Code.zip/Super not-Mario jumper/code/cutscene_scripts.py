#IMPORTING FILES
from settings import *
from cutscene_engine import CutsceneAction, DummyTarget

#IMPROTING LIBRARIES
from random import randint


class Cutscene1:

    # CLASS CONSTRUCTOR
    def __init__(s, level):
        s.level = level

    def start(s):
        player = s.level.player
        player.frozen = True
        cam_target = s.level
        boss = s.level.boss

        s.level.change_target_colour('#528AAE')
        s.level.set_music('none')
        s.sound_played = False
        s.land_sound_played = False

        # Get player camera anchor point (using top-left corner instead of center)
        player_anchor_topleft = pygame.Vector2(player.hitbox_rect.topleft) + player.pos_offset

        # Camera positions (based on the top-left corner)
        start_cam_pos = player_anchor_topleft
        end_cam_pos = start_cam_pos + pygame.Vector2(-530, 0)

        # Hitbox positions (physics base)
        player_start = pygame.Vector2(player.hitbox_rect.topleft)
        player_end = player_start + pygame.Vector2(-30, 0)

        boss_start = vector(boss.rect.bottomleft)
        boss_end = boss_start + vector(50, 1000)

        boss_start_2 = vector(boss_end)
        boss_end_2 = boss_start_2 + vector(50, 500)

        # Dummy camera target, aligned to same position logic as the player (top-left corner)
        dummy = DummyTarget(start_cam_pos)
        s.level.camera_target = dummy

        # Camera movement (away)
        def move_camera(p):
            pos = start_cam_pos.lerp(end_cam_pos, p)
            dummy.rect.topleft = pos
            dummy.hitbox_rect.topleft = pos

        # Move player hitbox along the ground
        def move_player(p):
            pos = player_start.lerp(player_end, p)
            player.hitbox_rect.topleft = pos

        # Camera movement (return)
        def move_camera_back(p):
            current_player_anchor_topleft = pygame.Vector2(player.hitbox_rect.topleft) + player.pos_offset
            pos = end_cam_pos.lerp(current_player_anchor_topleft, p)
            dummy.rect.topleft = pos
            dummy.hitbox_rect.topleft = pos

        # Player state control
        def run_state():
            player.facing_right = False
            player.direction.x = -1
            player.on_surface['floor'] = True
            player.state = 'run'

        def idle_state():
            player.direction.x = 0
            player.on_surface['floor'] = True
            player.state = 'idle'

        def boss_jump_up(p):
            if boss.rect.bottom > 1540 - 550:  # If boss is not yet at the peak height
                boss.rect.y -= 10  # Move the boss up by 5 pixels (adjust for speed)
                boss.rect.x += 3
                s.sound_played = False

        # Boss Land Function (Move down to simulate the landing)
        def boss_land(p):
            if boss.rect.bottom < 1540:  # If the boss is not yet on the ground
                boss.rect.y += 10  # Move the boss down by 5 pixels (adjust for speed)
                boss.rect.x += 6
            else:
                boss.rect.bottom = 1540
                if not s.land_sound_played:
                    s.level.sound_effects['boss_attack'].play()
                    s.land_sound_played = True

        def reset_camera():
            s.level.camera_target = player
            player.frozen = False
            s.level.boss.after_cutscene = True

        # Camera shake function (works by shifting the camera in random directions for a given duration)
        def shake_camera(p):
            # Store original position of the camera
            original_position = pygame.Vector2(s.level.camera_target.rect.topleft)

            # Duration for the shake
            shake_duration = 0.5  # Seconds
            shake_intensity = 10  # How strong the shake will be

            # Generate random offsets for shaking
            offset_x = randint(-shake_intensity, shake_intensity)
            offset_y = randint(-shake_intensity, shake_intensity)

            # Apply the shake by shifting the camera position
            s.level.camera_target.rect.topleft = original_position + pygame.Vector2(offset_x, offset_y)

            # After the shake duration, reset the camera back to its original position
            # You can adjust how long it should last
            if p >= shake_duration:
                s.level.camera_target.rect.topleft = original_position

        def boss_rawr_sound(p):
            if not s.sound_played:
                s.level.sound_effects['boss_rawr'].play()
                s.sound_played = True 

        def boss_fight_biome(p):
            s.level.change_target_colour('#FFBF00')
            s.level.set_music('level_1_boss_fight')

        # ACTION SEQUENCE (The cutscene actions and timings)
        actions = [
            CutsceneAction(0.01, lambda p: run_state()),
            CutsceneAction(2.0, lambda p: (move_camera(p), move_player(p))),
            CutsceneAction(0.01, lambda p: idle_state()),
            CutsceneAction(0.55, lambda p: (shake_camera(p), boss_rawr_sound(p))),
            CutsceneAction(2.0, lambda p: None),  # wait for boss
            CutsceneAction(1.2, lambda p: boss_jump_up(p)),  # boss starts to jump up
            CutsceneAction(0.1, lambda p: None),
            CutsceneAction(1.0, lambda p: (boss_land(p), shake_camera(p), boss_rawr_sound(p))),
            CutsceneAction(0.1, lambda p: boss_fight_biome(p)),
            CutsceneAction(1.0, lambda p: move_camera_back(p)),
            CutsceneAction(0.01, lambda p: reset_camera())
        ]

        s.level.cutscene_manager.start(actions)

