#IMPORTING LIBRARIES
import pygame

#IMPORTING FILES
from settings import *
from support import import_image
from utils import Button, Ball
from load_data import save_data


#OPTIONS MENU FOR WHEN ALREADY IN THE GAME
class GameMenuOptions:

    #CLASS CONSTRUCTOR
    def __init__(s, game):

        #PASSING IN THE GAME
        s.game = game