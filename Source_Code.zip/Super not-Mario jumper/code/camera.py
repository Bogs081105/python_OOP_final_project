#IMPORTING LIBRARIES
import random
import pygame
from pygame.math import Vector2 as vector

#IMPORTING FILES
from settings import *

class Camera(pygame.sprite.Group):

    def __init__(s):
        super().__init__()
        s.offset = vector()
        s.shake_duration = 0
        s.shake_magnitude = 40

    def start_shake(s, duration):
        s.shake_duration = duration

    def draw(s, surface, target_pos):

        # Base offset from player position
        s.offset.x = target_pos.hitbox_rect.x - WINDOW_WIDTH / 2
        s.offset.y = target_pos.hitbox_rect.y - WINDOW_HEIGHT / 2


        if target_pos.hit and s.shake_duration <= 0:
            s.start_shake(45)

        # Apply camera shake
        if s.shake_duration > 0:
            s.offset.x += random.randint(-s.shake_magnitude, s.shake_magnitude)
            s.offset.y += random.randint(-s.shake_magnitude, s.shake_magnitude)
            s.shake_duration -= 1

        screen_rect = pygame.Rect(s.offset.x, s.offset.y, WINDOW_WIDTH * 1.2, WINDOW_HEIGHT * 1.2)

        visible_sprites_count = 0
        for sprite in sorted(s, key=lambda sprite: sprite.z):
            if screen_rect.colliderect(sprite.rect):
                visible_sprites_count += 1
                surface.blit(sprite.image, sprite.rect.topleft - s.offset)

        print(f'{visible_sprites_count} sprites drawn')

        