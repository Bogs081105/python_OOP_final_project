#IMPORTING LIBRARIES
import pygame

#IMPORTING FILES
from settings import *
from support import import_image, import_folder, import_sound_effect
from utils import Button

#IMPORTING CLASSES
from main_menu_options import MainMenuOptions


#MAIN MENU CLASS
class MainMenu:

    #MAIN MENU CLASS CONSTRUCTOR
    def __init__(s, game):

        #PASSING IN THE GAME AS AN ATTRIBUTE
        s.game = game

        #MAIN MENU STATE
        s.main_menu_state = 'menu'

        #MENU ASSETS
        s.background = import_image('..', 'graphics', 'utils', 'main_menu_background')
        s.buttons = pygame.sprite.Group()
        s.menu_sound_up = import_sound_effect('..', 'audio', 'menu_move_up')
        s.menu_sound_down = import_sound_effect('..', 'audio', 'menu_move_down')
        s.menu_select = import_sound_effect('..', 'audio', 'menu_select')
        pygame.mixer.music.load(join('..', 'audio', 'background_tracs', 'main_menu.ogg'))
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(-1)

        #MAIN MENU ELEMENTS
        s.options = MainMenuOptions(s.game, s.menu_sound_up, s.menu_sound_down, s.menu_select)

        s.continue_button = Button(s.game, 'Play', (s.game.screen.get_width() / 2 - 175, 135), s.buttons, size = (350, 80), action = lambda: s.game.change_active_element('level'))
        s.options_button = Button(s.game, 'Options', (s.game.screen.get_width() / 2 - 175, 220), s.buttons, size = (350, 80), action = lambda: s.change_active_mm_element('options'))
        s.extras_button = Button(s.game, 'Extras', (s.game.screen.get_width() / 2 - 175, 305), s.buttons, size = (350, 80), action = lambda: s.change_active_mm_element('extras'))
        s.exit_button = Button(s.game, 'Exit', (s.game.screen.get_width() / 2 - 175, 390), s.buttons, size = (350, 80), action = lambda: s.exit_button())

        # INDICATOR SETUP FOR KEYBOARD/GAMEPAD CONTROL
        s.selected_button_index = 0
        s.indicator_frames = import_folder('..', 'graphics', 'utils', 'indicator')

        #SCALING FRAMES
        s.indicator_frames = [pygame.transform.scale(frame, (400, 120)) for frame in s.indicator_frames]

        s.indicator_frame_index = 0
        s.indicator_frame_animation_speed = 2
        s.indicator_image = s.indicator_frames[0]
        s.indicator_rect = s.indicator_image.get_rect(center = s.continue_button.rect.center + vector(0, -5))

        

    #METHOD FOR INPUT
    def input(s):
        
        keys = pygame.key.get_just_pressed()
        mouse = pygame.mouse.get_just_pressed()[0]

        if (keys[pygame.K_DOWN] or keys[pygame.K_s]) and s.selected_button_index < len(s.buttons)-1:
            s.selected_button_index += 1
            s.menu_sound_down.play()
        elif (keys[pygame.K_UP] or keys[pygame.K_w]) and s.selected_button_index > 0:
            s.selected_button_index -= 1
            s.menu_sound_up.play()

        if keys[pygame.K_RETURN] or keys[pygame.K_KP_ENTER]:
            button_list = list(s.buttons)
            selected_button = button_list[s.selected_button_index]
            if hasattr(selected_button, 'action') and callable(selected_button.action):
                selected_button.action()
                s.menu_select.play()

        if mouse:
            s.menu_select.play()

    #METHOD FOR UPDATING THE MENU
    def update(s, delta_time):

        if s.main_menu_state == 'menu':
            for button in s.buttons:
                button.update()

            s.input()
            s.indicator_rect.y = s.continue_button.rect.y - 20 + (s.continue_button.rect.height + 5) * s.selected_button_index
            s.animate(delta_time)

        elif s.main_menu_state == 'options':
            s.options.update(delta_time)

    #METHOD FOR DRAWING THE MENU
    def draw(s):

        s.game.screen.blit(s.background, (0,0))

        if s.main_menu_state == 'menu':
            for button in s.buttons:
                button.draw()

            s.game.screen.blit(s.indicator_image, s.indicator_rect)

        elif s.main_menu_state == 'options':
            s.options.draw()

    #METHOD FOR ANIMATION
    def animate(s, delta_time):

        s.indicator_frame_index += s.indicator_frame_animation_speed * delta_time
        indicator_frame_count = len(s.indicator_frames)
        s.indicator_image = s.indicator_frames[int(s.indicator_frame_index % indicator_frame_count)]

    #METHOD FOR EXIT BUTTON
    def exit_button(s):
        pygame.quit()
        exit()

    #METHOD FOR CHANGING ACTIVE MAIN MENU ELEMENT
    def change_active_mm_element(s, new_state):
        s.main_menu_state = new_state
