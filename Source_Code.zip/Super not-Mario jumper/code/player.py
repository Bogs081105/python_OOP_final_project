#IMPORTING FILES
from settings import *

#IMPORTING CLASSES
from utils import Timer

#PLAYER CLASS
class Player(pygame.sprite.Sprite):

    #PLAYER CLASS CONSTRUCTOR
    def __init__(s, level, pos, frames, groups, collision_sprites , semi_collision_sprites, sound_effects, damage_sprites):

        #INITIALIZING INHERITANCE
        super().__init__(groups)

        #PASSING IN THE LEVEL FOR TESTING
        s.level = level

        #SETTING UP FRAMES
        s.frames = frames

        #SETTING UP SPRITE
        s.frame_index = 0
        s.state = 'idle'
        s.previous_state = s.state
        s.facing_right = True
        s.animation_speed = 6
        s.image = s.frames[s.state][s.frame_index]
        s.base_width = 48

        #KATANA!?
        s.has_katana = False
        s.attacking = False
        s.special_attacking = False
        s.player_attack_rect = None

        #FOREGROUND/BACKGROUND "3D" EFFECT
        s.z = Z_LAYERS['main_terrain']

        #RECTANGLES
        s.rect = s.image.get_frect(center = pos)
        s.hitbox_rect = s.rect.inflate(-75, -65)
        s.pos_offset = vector(0, 12)
        s.old_rect = s.hitbox_rect.copy()

        #PLAYER FEET RECT FOR CHECKING SEMI COLLIDABLE PLATFORMS
        s.feet_rect = pygame.Rect(0, 0, s.hitbox_rect.width * 0.9, 1)
        s.feet_rect.midtop = s.hitbox_rect.midbottom

        #MOVEMENT ATTRIBUTES
        s.frozen = False
        s.jump = False
        s.jump_height = 650
        s.speed = 280
        s.gravity = 1200
        s.direction = vector()

        #DIFFERENT ANIMATION SPEEDS DEPENDING ON STATE
        s.animation_speeds = {
            'idle': 14,
            'run': 14,
            'jump': 16,
            'wall_left': 8,
            'wall_right': 8,
            'katana_idle': 14,
            'katana_run': 14,
            'attack': 14,
            'special_attack' : 20,
            'hurt' : 1,
            'death' : 1
        }

        #OFFSETS FOR RECTANGLE LAYING ON HITBOX
        s.offsets = {
            'idle': vector(0, 12),
            'run': vector(0, 12),
            'jump': vector(0, 12),
            'wall_left': vector(10, 12),
            'wall_right': vector(-10, 12),
            'attack': vector(50, 12),
            'special_attack' : vector(36, 32)
        }
        s.attack_correction_offset_frame = False
        s.special_attack_correction_frame = False

        #COLLISION SPRITES
        s.collision_sprites = collision_sprites
        s.semi_collision_sprites = semi_collision_sprites
        s.damage_sprites = damage_sprites
        s.sound_effects = sound_effects
        s.on_surface = {'floor' : False, 'left' : False, 'right' : False}
        s.platform = None
        s.hit = False
        s.dead = False
        s.health = 1

        #TIMERS
        s.timers = {
            'wall_jump' : Timer(400),
            'wall_slide_block' : Timer(600),
            'platform_skip' : Timer(400),
            'invonrability' : Timer(400)
        }

    #METHOD FOR PLAYER INPUT
    def input(s):

        #ONLY IF PLAYERS IS NOT FROZEN
        if s.frozen or s.health <= 0 or s.dead:
            return

        #GETTING ALL KEYS PRESSED BY PLAYER
        mouse = pygame.mouse.get_just_pressed()
        keys = pygame.key.get_pressed()
        keys_j = pygame.key.get_just_pressed()

        #PLAYER INPUT VECTOR
        input_vector = vector()

        #CUTSCENE - TESTING
        if keys_j[pygame.K_h] and not s.level.cutscene_manager.active:
            s.level.start_camera_pan_cutscene()

        #GET KATANA - TESTING
        if keys_j[pygame.K_k]:
            s.has_katana = not s.has_katana

        if keys_j[pygame.K_l]:
            s.health -= 1

        #PLAYER ATTACKING
        if (keys_j[pygame.K_c] or mouse[0]) and s.has_katana and not s.special_attacking:
            s.attack()
        elif (keys_j[pygame.K_v] or mouse[2]) and s.has_katana and not s.attacking:
            s.special_attack()
            s.sound_effects['attack'].play()

        #PLAYER MOVEMENT UP / DOWN
        if keys[pygame.K_UP] or keys[pygame.K_w] or keys[pygame.K_SPACE]:
            s.jump = True

        if (keys_j[pygame.K_UP] or keys_j[pygame.K_w] or keys_j[pygame.K_SPACE]) and any((s.on_surface['floor'], s.on_surface['right'], s.on_surface['left'])):
            s.sound_effects['jump'].play()
        elif keys_j[pygame.K_DOWN] or keys_j[pygame.K_s]:
            s.timers['platform_skip'].activate()

        #PLAYER MOVEMENT LEFT / RIGHT
        if not s.timers['wall_jump'].active:
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                input_vector.x = -1
                s.facing_right = False
            elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                input_vector.x = 1
                s.facing_right = True

            #PLAYER MOVEMENT DIRECTION IS BASED ON HIS VELOCITY
            s.direction.x = input_vector.normalize().x if input_vector else input_vector.x

    #METHOD FOR ATTACKING
    def attack(s):
        s.attacking = True

    #SPECIAL ATTACK
    def special_attack(s):
        s.special_attacking = True

        # Get correct offset based on current animation state
        offset = s.offsets.get('special_attack', vector(0, 0))

        # Base attack rect on the hitbox, not image rect
        attack_origin_x = s.hitbox_rect.centerx + (90 if s.facing_right else -110)
        attack_origin_y = s.hitbox_rect.centery + offset.y - 40  # Apply vertical offset

        # Create attack rect
        s.player_attack_rect = pygame.Rect(0, 0, 80, 60)
        s.player_attack_rect.center = (attack_origin_x, attack_origin_y)

    #METHOD FOR MOVING PLAYER
    def move(s, delta_time):

        #MOVING PLAYER VERTICALLY
        if not s.on_surface['floor'] and any((s.on_surface['right'], s.on_surface['left'])) and not s.timers['wall_slide_block'].active:    #PLAYER STICKING TO WALL
            s.direction.y = 0
            s.hitbox_rect.y += s.gravity / 10 * delta_time

        else:   #PLAYER FREE FALLING
            s.direction.y += s.gravity / 2 * delta_time
            s.hitbox_rect.y += s.direction.y * delta_time
            s.direction.y += s.gravity / 2 * delta_time
        s.collision('vertical')

        #MOVE PLAYER HORIZONTALLY
        s.hitbox_rect.x += s.direction.x * s.speed * delta_time
        s.collision('horizontal')


        #PLAYER JUMPING
        if s.jump:
            if s.on_surface['floor']:   #REGULAR JUMP
                s.direction.y = -s.jump_height
                s.timers['wall_slide_block'].activate()
                s.hitbox_rect.bottom -= 1

            elif any((s.on_surface['right'], s.on_surface['left'])) and not s.timers['wall_slide_block'].active:    #WALL JUMP
                s.timers['wall_jump'].activate()
                s.direction.y = -s.jump_height
                s.direction.x = 1 if s.on_surface['left'] else -1

            #SETTING JUMP BACK TO FALSE
            s.jump = False
            
    #METHOD FOR BEING ON MOVING PLATFORM
    def platform_move(s, delta_time):
        if s.platform:
            s.hitbox_rect.x += s.platform.direction.x * s.platform.speed * delta_time
            s.hitbox_rect.y += s.platform.direction.y * s.platform.speed * delta_time

    #METHOD FOR CHECKING PLAYER - FLOOR/WALL CONTACT
    def check_contact(s):

        #RECTANGLES FOR CHECKING IF PLAYER CAN JUMP
        floor_rect = pygame.Rect(s.hitbox_rect.bottomleft, (s.hitbox_rect.width,2))
        right_rect = pygame.Rect(s.hitbox_rect.topright + vector(0, s.hitbox_rect.height/4), (2, s.hitbox_rect.height / 2))
        left_rect = pygame.Rect(s.hitbox_rect.topleft + vector(-2, s.hitbox_rect.height/4), (2, s.hitbox_rect.height / 2))

        #LIST OF FLOOR AND WALL RECTS
        collide_rects = [sprite.rect for sprite in s.collision_sprites]
        semi_collide_rect = [sprite.rect for sprite in s.semi_collision_sprites]

        #COLLISIONS
        s.on_surface['floor'] = True if floor_rect.collidelist(collide_rects) >= 0 or floor_rect.collidelist(semi_collide_rect) >= 0 and s.direction.y >= 0 else False
        s.on_surface['right'] = True if right_rect.collidelist(collide_rects) >= 0 else False
        s.on_surface['left'] = True if left_rect.collidelist(collide_rects) >= 0 else False

        #CHECKING IN PLAYER IS ON MOVABLE PLATFORM
        s.platform = None
        sprites = s.collision_sprites.sprites() + s.semi_collision_sprites.sprites()
        for sprite in [sprite for sprite in sprites if hasattr(sprite, 'moving')]:
            if sprite.rect.colliderect(floor_rect):
                s.platform = sprite

    #METHOD FOR CHECKING COLLISIONS
    def collision(s, axis):

        #CHECKING COLLISION WITH EVERY SPRITE IN COLLISION SPRITES
        for sprite in s.collision_sprites:
            if sprite.rect.colliderect(s.hitbox_rect):

                if axis == 'horizontal':
                    if s.direction.x > 0:  #MOVING RIGHT
                        s.hitbox_rect.right = sprite.rect.left
                    elif s.direction.x < 0:  #MOVING LEFT
                        s.hitbox_rect.left = sprite.rect.right

                if axis == 'vertical':
                    if s.direction.y > 0:  #MOVING DOWN
                        s.hitbox_rect.bottom = sprite.rect.top
                
                    elif s.direction.y < 0:  #MOVING UP
                        s.hitbox_rect.top = sprite.rect.bottom
                        if hasattr(sprite, 'moving'):
                            s.hitbox_rect.top
                
                    #SETTING DIRECTION.Y TO 0 IF WE HAVE ANY VERTICAL COLLISION
                    s.direction.y = 0

    #METHOD FOR SEMI COLLISION PLATFORMS
    def semi_collision(s):
        for sprite in s.semi_collision_sprites:
            if sprite.rect.colliderect(s.feet_rect):

                if s.direction.y > 0 and not s.timers['platform_skip'].active:  #MOVING DOWN
                        s.hitbox_rect.bottom = sprite.rect.top
                        if s.direction.y > 0:
                            s.direction.y = 0

    #METHOD FOR CHECKING IF THE PLAYER GOT HIT
    def damage_collisions(s):
        for sprite in s.damage_sprites:
            if sprite.is_damaging:
                if sprite.rect.colliderect(s.hitbox_rect) and not s.timers['invonrability'].active:
                    s.hit = True
                    s.frozen = True

    #METHOD FOR UPDATING TIMERS
    def update_timers(s):
        for timer in s.timers.values():
            timer.update()

    #METHOD FOR ANIMATING THE PLAYER
    def animate(s, delta_time):

        #RESETING THE ANIMATION INDEX WITH STATES
        if s.state != s.previous_state:
            s.frame_index = 0
            s.previous_state = s.state

        #UPDATING THE FRAME INDEX
        s.frame_index += s.animation_speed * delta_time
        frame_list = s.frames[s.state]
        frame_count = len(frame_list)

        #SPECIFIC FINISHED ANIMATIONS
        if s.state == 'jump' and s.frame_index >= frame_count:  #JUMPING
            s.image = frame_list[-1]

        elif (s.state == 'wall_left' or s.state == 'wall_right') and s.frame_index >= frame_count:
            s.image = frame_list[-1]

        elif s.state == 'death' and s.frame_index >= frame_count:
            s.dead = True

        elif s.state == 'hurt' and s.frame_index >= frame_count:
            s.hit = False
            s.state = 'idle'
            s.frozen = False
            s.timers['invonrability'].activate()

        elif s.state == 'attack' and s.frame_index >= frame_count:  #ATTACKING
            s.state = 'idle'
            s.attacking = False
            s.attack_correction_offset_frame = True

        elif s.state == 'special_attack' and s.frame_index >= frame_count:  #SPECIAL ATTACK
            s.state = 'idle'
            s.special_attacking = False
            s.special_attack_correction_frame = True
            s.player_attack_rect = None
            

        else:   #NOTHING
            s.image = frame_list[int(s.frame_index % frame_count)]

        #FLIPPING SPRITE IF NEEDED
        s.image = s.image if s.facing_right else pygame.transform.flip(s.image, True, False)

        #IMPELEMENTING ATTACK THE OFFSET
        if s.attack_correction_offset_frame:
            s.pos_offset = s.offsets.get('attack', vector(0, 12))

        elif s.special_attack_correction_frame:
            s.pos_offset = s.offsets.get('special_attack', vector(0, 12))

        else:
            s.pos_offset = s.offsets.get(s.state, vector(0, 12))

    #METHOD FOR GETTING ANIMATION STATE
    def get_state(s):

        if s.health <= 0:
            s.state = 'death'
            return

        if s.hit:
            s.state = 'hurt'
            return

        #PLAYER IS ON THE FLOOR
        if s.on_surface['floor']:

            #PLAYER HAS THE KATANA
            if s.has_katana:

                #PLAYER IS ATTACKING
                if s.attacking:
                    s.state = 'attack'
                elif s.special_attacking:
                    s.state = 'special_attack'
                
                #PLAYER PASSIVE
                else:
                    s.state = 'katana_idle' if s.direction.x == 0 else 'katana_run'

            #PLAYER DOESN'T HAVE THE KATANA
            else:
                s.state = 'idle' if s.direction.x == 0 else 'run'

        #PLAYER IS IN THE AIR
        else:

            #PLAYER HAS THE KATANA
            if s.has_katana:

                #PLAYER IS ATTACKING
                if s.attacking:
                    s.state = 'attack'
                elif s.special_attacking:
                    s.state = 'special_attack'

                #PLAYER IS NOT ATTACKING
                else:
                    if s.on_surface['left']:
                        s.facing_right = True
                        s.state = 'wall_left'
                    elif s.on_surface['right']:
                        s.facing_right = True
                        s.state = 'wall_right'
                    else:
                        s.state = 'jump'

            #PLAYER DOESN'T HAVE THE KATANA
            else:
                if s.on_surface['left']:
                    s.facing_right = True
                    s.state = 'wall_left'
                elif s.on_surface['right']:
                    s.facing_right = True
                    s.state = 'wall_right'
                else:
                    s.state = 'jump'

        #UPDATING THE ANIMATION SPEED
        if s.state == 'attack': s.animation_speed = s.animation_speeds['attack']
        elif s.state == 'jump': s.animation_speed = s.animation_speeds['jump']
        elif s.state == 'idle': s.animation_speed = s.animation_speeds['idle']
        elif s.state == 'wall_left': s.animation_speed = s.animation_speeds['wall_left']
        elif s.state == 'wall_right': s.animation_speed = s.animation_speeds['wall_right']
        elif s.state == 'katana_run': s.animation_speed = s.animation_speeds['katana_run']
        elif s.state == 'katana_idle': s.animation_speed = s.animation_speeds['katana_idle']
        elif s.state == 'special_attack' : s.animation_speed = s.animation_speeds['special_attack']
        elif s.state == 'hurt' : s.animation_speed = s.animation_speed['hurt']
        elif s.state == 'death' : s.animation_speed = s.animation_speed['death']
        else: s.animation_speed = 14

        #UPDATING PLAYER SPEED
        if s.state == 'attack': s.speed = 800
        elif s.state == 'hurt' : s.speed = 100
        else: s.speed = 280

    #METHOD FOR UPDATING PLAYER
    def update(s, delta_time):

        #GETTING THE 'OLD' PLAYER RECTANGLE POS
        s.old_rect = s.hitbox_rect.copy()

        #UPDATING ALL TIMERS
        s.update_timers()

        #HANDLING PLAYER INPUT
        s.input()

        #HANDLING PLAYER MOVEMENT
        s.move(delta_time)

        #MOVING PLAYER ON A PLATFORM
        s.platform_move(delta_time)#SETTING PLAYER SUPPORT RECTANGES TO NEW POSSITION
        s.rect.center = s.hitbox_rect.center - s.pos_offset
        s.feet_rect.midtop = s.hitbox_rect.midbottom

        #CHECKING PLAYER CONTACT WITH FLOOR/WALL - FOR JUMP/WALLJUMP
        s.check_contact()
        
        #HANDLING THE PLAYER 'COLLIDING' WITH THE SEMI COLLISION PLATFORMS
        s.semi_collision()

        #CHECKING IF PLAYER IS DAMAGED
        s.damage_collisions()

        #ANIMATING THE PLAYER
        s.get_state()
        s.animate(delta_time)

        #SETTING PLAYER SUPPORT RECTANGES TO NEW POSSITION
        s.rect.center = s.hitbox_rect.center - s.pos_offset
        s.feet_rect.midtop = s.hitbox_rect.midbottom
        s.attack_correction_offset_frame = False
        s.special_attack_correction_frame = False

        if s.rect.y > 1600:
            s.dead = True