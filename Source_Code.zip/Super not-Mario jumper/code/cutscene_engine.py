#IMPORTING FILES
from settings import *


#CLASS FOR ACTIONS IN A CUTSCENE
class CutsceneAction:

    #CUTSCENE ACTION CONSTRUCTOR
    def __init__(s, duration, update_function):

        s.duration = duration                   #HOW LONG DOES THE ACTION LAST (IN SECONDS)
        s.update_function = update_function     #FUNCTION TO CALL EACH FRAME (TAKES PROGRESS)
        s.timer = 0
        s.done = False

    
    #METHOD FOR UPDATING THE ACTION
    def update(s, delta_time):

        #IF THE ACTION HAS FINISHED
        if s.done:
            return True
        
        s.timer += delta_time   #ADDING TO THE AMOUNT OF TIME THE ACTION HAS BEEN ALREADY WORKING
        progress = 1.0 if s.duration == 0 else min(1.0, s.timer / s.duration)   #HOW LONG HAS THE ACTION BEEN WORKING FOR
        s.update_function(progress)


        #IF THE PROGRESS IS 1.0, THE ACTION HAS FINISHED
        if progress >= 1.0:
            s.done = True
        return s.done 




#CLASS FOR MANAGING CUTSCENES
class CutsceneManager:

    #CUTSCENE MANAGER CONSTRUCTOR
    def __init__(s):

        s.actions = []      #LIST OF CUTSCENE ACTIONS | CUTSCENEACTION OBJECTS
        s.current_action = None    #THE CURRENT ACTION BEING EXECUTED
        s.active = False    #WHETHER A CUTSCENE IS CURRENTLY PLAYING


    #METHOD THAT STARTS THE CUTSCENE
    def start(s, actions):

        s.actions = actions
        s.current_action = None
        s.active = True
        

    #METHOD FOR UPDATING THE CUTSCENES
    def update(s, delta_time):

        #IF THE CUTSCENE IS NOT ACTIVE 'SKIP' THE UPDATE
        if not s.active:
            return
        
        #MAKING THE CURRENT ACTION THE FIRST ACTION IN ACTIONS AND POPING IT SO IT DOESN'T REPEAT
        if not s.current_action and s.actions:
            s.current_action = s.actions.pop(0)

        
        #IF THERE IS A CURRENT ACTION
        if s.current_action:

            #CHECKING IF THE ACTIONS UPDATE METHOD RETURNS THAT IT HAS FINISHED
            done = s.current_action.update(delta_time)

            #SETTING THE CURRENT ACTION BACK TO NONE
            if done:
                s.current_action = None


        #IF THERE ARE NO MORE ACTIONS AND NO CURRENT ACTION THE CURSCENE HAS ENDED
        if not s.actions and not s.current_action:
            s.active = False


#DUMMY TARGET CLASS FOR MOVING THE CAMERA
class DummyTarget(pygame.sprite.Sprite):

    #DUMMY TARGET CONSTRUCTOR
    def __init__(s, pos):

        #INITIALIZING INHERITANCE
        super().__init__()

        #CLASS ATTRIBUTES
        s.image = pygame.Surface((1, 1))
        s.image.fill((0, 0, 0))
        s.rect = s.image.get_frect(topleft = pos)
        s.hitbox_rect = s.rect
        s.hit = False