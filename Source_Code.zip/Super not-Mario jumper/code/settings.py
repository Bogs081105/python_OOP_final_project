#IMPROTING LIBRARIES
import pygame
from pygame.math import Vector2 as vector
from os.path import join


#SCREEN / WINDOW SETTINGS
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
SCREEN_DATA_PATH = join('..', 'save_data', 'screen_data.json')
DEFAULT_SCREEN_DATA = {
    'width' : 1280,
    'height' : 720,
    'fullscreen' : False,
    'fps' : 60
}

#TILE SETTINGS
TILE_SIZE = 64

#ANIMATION SETTINGS
ANIMATION_SPEED = 6

#LAYER DEPTH SETTINGS
Z_LAYERS = {
    'background' : 0,
    'clouds' : 1,
    'background_terrain' : 2,
    'path' : 3,
    'background_details' : 4,
    'main_terrain' : 5,
    'water' : 6,
    'foreground_terrain' : 7,
    'foreground' : 8
}