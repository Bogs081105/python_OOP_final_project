<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="outside" tilewidth="64" tileheight="64" tilecount="48" columns="12">
 <image source="../../graphics/tilesets/outside.png" width="768" height="256"/>
</tileset>
