<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1-99-gec89c545" name="level_1_boss" tilewidth="80" tileheight="105" tilecount="1" columns="1">
 <image source="../../graphics/enemies/level_1_boss/idle/0.png" width="80" height="105"/>
</tileset>
