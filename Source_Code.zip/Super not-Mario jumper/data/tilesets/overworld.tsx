<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="overworld" tilewidth="64" tileheight="64" tilecount="126" columns="14">
 <image source="../../graphics/tilesets/overworld.png" width="896" height="576"/>
</tileset>
